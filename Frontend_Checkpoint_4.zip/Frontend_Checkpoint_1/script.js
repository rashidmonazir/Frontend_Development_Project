 // Change countries dynamically in the welcome section
 const places = ["New York", "Tokyo", "Paris", "Berlin", "Sydney", "London"];
 let index = 0;

 setInterval(() => {
     document.getElementById("place-name").textContent = "Visit " + places[index];
     index = (index + 1) % places.length;
 }, 2000);

 // Booking Form Submission
 document.getElementById('booking-form').addEventListener('submit', function(event) {
     event.preventDefault();

     // Get the input values
     const startDate = new Date(document.getElementById('start-date').value);
     const endDate = new Date(document.getElementById('end-date').value);

     // Validate dates
     if (endDate <= startDate) {
         alert('End Date must be greater than Start Date.');
         return;
     }

     alert('Booking successful!');
     // You may want to reset the form or redirect the user
     this.reset();
 });

    // Set min date for start date and end date inputs
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('start-date').setAttribute('min', today);
    document.getElementById('end-date').setAttribute('min', today);


// Registration Form Validation
document.getElementById('registerForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    const fullname = document.getElementById('fullname').value.trim();
    const contact = document.getElementById('contact').value.trim();
    const dob = document.getElementById('dob').value;
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    const gender = document.getElementById('gender').value;

    // Basic validation
    if (!fullname || !contact || !dob || !email || !password || !gender) {
        alert('Please fill all the fields.');
        return;
    }

    // Email validation
    if (!validateEmail(email)) {
        alert('Please enter a valid email address.');
        return;
    }

    // Contact number validation (Assuming a 10-digit format for simplicity)
    if (!validateContact(contact)) {
        alert('Please enter a valid contact number (10 digits).');
        return;
    }

    // Password validation
    if (!validatePassword(password)) {
        alert('Password must be at least 6 characters long, include at least one uppercase letter, one lowercase letter, one number, and one special character.');
        return;
    }

    alert('Registration successful!');
    this.reset(); // Reset the form
    $('#registerModal').modal('hide'); // Hide the modal
});

// Login Form Validation
document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    const email = document.getElementById('loginEmail').value.trim();
    const password = document.getElementById('loginPassword').value;

    // Basic validation
    if (!email || !password) {
        alert('Please fill all the fields.');
        return;
    }

    // Email validation
    if (!validateEmail(email)) {
        alert('Please enter a valid email address.');
        return;
    }

    // Password validation
    if (!validatePassword(password)) {
        alert('Password must be at least 6 characters long, include at least one uppercase letter, one lowercase letter, one number, and one special character.');
        return;
    }

    alert('Login successful!');
    this.reset(); // Reset the form
    $('#loginModal').modal('hide'); // Hide the modal
});

// Basic email validation function
function validateEmail(email) {
    const regex = /^\S+@\S+\.\S+$/;
    return regex.test(email);
}

// Contact validation function
function validateContact(contact) {
    const regex = /^\d{10}$/; // Validates a 10-digit number
    return regex.test(contact);
}

// Password validation function
function validatePassword(password) {
    const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,}$/; 
    // Requires at least one uppercase letter, one lowercase letter, one number, and one special character
    return regex.test(password);
}
